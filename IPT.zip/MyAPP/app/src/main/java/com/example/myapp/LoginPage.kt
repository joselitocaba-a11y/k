package com.example.myapp

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class LoginPage : AppCompatActivity() {

    private lateinit var editTextEmail: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var loginButton: Button
    private lateinit var rememberPasswordCheckBox: CheckBox
    private lateinit var forgotPasswordText: EditText
    private lateinit var createAccountText: EditText
    private lateinit var facebookLoginText: TextView
    private lateinit var instagramLoginText: TextView
    private lateinit var facebookIcon: ImageView
    private lateinit var instagramIcon: ImageView

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.login_page)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.LoginPage)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE)

        initializeViews()
        setupEventListeners()
        setupPlaceholderBehavior()
        loadRememberedCredentials()

        val registeredEmail = intent.getStringExtra("REGISTERED_EMAIL")
        if (!registeredEmail.isNullOrEmpty()) {
            editTextEmail.setText(registeredEmail)
            editTextPassword.requestFocus()
        }
    }

    private fun initializeViews() {
        editTextEmail = findViewById(R.id.editTextTextEmailAddress)
        editTextPassword = findViewById(R.id.editTextTextPassword)

        loginButton = findViewById(R.id.button)
        rememberPasswordCheckBox = findViewById(R.id.checkBox)
        forgotPasswordText = findViewById(R.id.editTextText)
        createAccountText = findViewById(R.id.editTextText2)

        facebookLoginText = findViewById(R.id.textView7)
        instagramLoginText = findViewById(R.id.textView9)
        facebookIcon = findViewById(R.id.imageView4)
        instagramIcon = findViewById(R.id.imageView5)
    }

    private fun setupPlaceholderBehavior() {
        editTextEmail.setOnFocusChangeListener { _, hasFocus ->
            val currentText = editTextEmail.text.toString().trim()
            if (hasFocus && (currentText.contains("Email Address") || currentText.isEmpty())) {
                editTextEmail.setText("")
            }
        }

        editTextPassword.setOnFocusChangeListener { _, hasFocus ->
            val currentText = editTextPassword.text.toString().trim()
            if (hasFocus && (currentText.contains("Password") || currentText.isEmpty())) {
                editTextPassword.setText("")
            }
        }
    }

    private fun loadRememberedCredentials() {
        val rememberedEmail = sharedPreferences.getString("remembered_email", "")
        val rememberedPassword = sharedPreferences.getString("remembered_password", "")

        if (!rememberedEmail.isNullOrEmpty() && !rememberedPassword.isNullOrEmpty()) {
            editTextEmail.setText(rememberedEmail)
            editTextPassword.setText(rememberedPassword)
            rememberPasswordCheckBox.isChecked = true
        }
    }

    private fun setupEventListeners() {
        loginButton.setOnClickListener { handleLogin() }

        forgotPasswordText.setOnClickListener {
            handleForgotPassword()
        }

        createAccountText.setOnClickListener {
            val intent = Intent(this@LoginPage, MainActivity::class.java)
            startActivity(intent)
        }

        facebookLoginText.setOnClickListener { handleFacebookLogin() }
        facebookIcon.setOnClickListener { handleFacebookLogin() }

        instagramLoginText.setOnClickListener { handleInstagramLogin() }
        instagramIcon.setOnClickListener { handleInstagramLogin() }
    }

    private fun handleLogin() {
        var email = editTextEmail.text.toString().trim()
        var password = editTextPassword.text.toString().trim()

        if (email.contains("Email Address") || email.isEmpty()) {
            email = ""
        }
        if (password.contains("Password") || password.isEmpty()) {
            password = ""
        }

        if (email.isEmpty()) {
            Toast.makeText(this, "Please enter your email address", Toast.LENGTH_SHORT).show()
            editTextEmail.requestFocus()
            return
        }

        if (!isValidEmail(email)) {
            Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show()
            editTextEmail.requestFocus()
            return
        }

        if (password.isEmpty()) {
            Toast.makeText(this, "Please enter your password", Toast.LENGTH_SHORT).show()
            editTextPassword.requestFocus()
            return
        }

        if (authenticateUser(email, password)) {
            val fullName = sharedPreferences.getString("user_${email}_fullname", "User") ?: "User"

            if (rememberPasswordCheckBox.isChecked) {
                saveCredentials(email, password)
            } else {
                clearSavedCredentials()
            }

            Toast.makeText(this, "Welcome back, $fullName!", Toast.LENGTH_SHORT).show()

            // Navigate to home page
            val intent = Intent(this@LoginPage, HomePageActivity::class.java)
            intent.putExtra("FULLNAME", fullName)
            intent.putExtra("EMAIL", email)
            startActivity(intent)
            finish()
        } else {
            Toast.makeText(this, "Invalid email or password. Please try again.", Toast.LENGTH_LONG).show()
            editTextPassword.setText("")
        }
    }

    private fun authenticateUser(email: String, password: String): Boolean {
        if (email == "admin@myapp.com" && password == "admin123") {
            with(sharedPreferences.edit()) {
                putString("user_${email}_fullname", "Admin User")
                apply()
            }
            return true
        }

        val savedPassword = sharedPreferences.getString("user_${email}_password", null)
        return savedPassword != null && savedPassword == password
    }

    private fun handleForgotPassword() {
        val email = editTextEmail.text.toString().trim()

        if (email.isEmpty() || email.contains("Email Address")) {
            Toast.makeText(this, "Please enter your email address first", Toast.LENGTH_SHORT).show()
            editTextEmail.requestFocus()
            return
        }

        if (!isValidEmail(email)) {
            Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show()
            editTextEmail.requestFocus()
            return
        }

        Toast.makeText(this, "Password reset instructions have been sent to $email", Toast.LENGTH_LONG).show()

    }

    private fun handleFacebookLogin() {
        Toast.makeText(this, "Connecting to Facebook...", Toast.LENGTH_SHORT).show()

        val intent = Intent(this@LoginPage, HomePageActivity::class.java)
        intent.putExtra("FULLNAME", "Facebook User")
        intent.putExtra("EMAIL", "facebook.user@example.com")
        startActivity(intent)
        finish()
    }

    private fun handleInstagramLogin() {
        Toast.makeText(this, "Connecting to Instagram...", Toast.LENGTH_SHORT).show()

        val intent = Intent(this@LoginPage, HomePageActivity::class.java)
        intent.putExtra("FULLNAME", "Instagram User")
        intent.putExtra("EMAIL", "instagram.user@example.com")
        startActivity(intent)
        finish()
    }

    private fun saveCredentials(email: String, password: String) {
        with(sharedPreferences.edit()) {
            putString("remembered_email", email)
            putString("remembered_password", password)
            apply()
        }
    }

    private fun clearSavedCredentials() {
        with(sharedPreferences.edit()) {
            remove("remembered_email")
            remove("remembered_password")
            apply()
        }
    }

    private fun isValidEmail(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    override fun onBackPressed() {
        // Navigate back to landing page
        val intent = Intent(this@LoginPage, LandingPage::class.java)
        startActivity(intent)
        finish()
    }
}