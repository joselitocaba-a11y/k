package com.example.myapp

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


class MainActivity : AppCompatActivity() {

    private lateinit var editTextTextFullName: EditText
    private lateinit var editTextTextContactNumber: EditText
    private lateinit var editTextTextEmailAddress: EditText
    private lateinit var editTextTextPassword: EditText
    private lateinit var editTextTextPassword2: EditText
    private lateinit var buttonCreateAccount: Button
    private lateinit var checkBox: CheckBox
    private lateinit var textViewFacebook: TextView
    private lateinit var textViewInstagram: TextView

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE)

        initializeViews()

        setupEventListeners()
    }

    private fun initializeViews() {
        // Initialize form fields
        editTextTextFullName = findViewById(R.id.editTextTextFullName)
        editTextTextContactNumber = findViewById(R.id.editTextTextContactNumber)
        editTextTextEmailAddress = findViewById(R.id.editTextTextEmailAddress)
        editTextTextPassword = findViewById(R.id.editTextTextPassword)
        editTextTextPassword2 = findViewById(R.id.editTextTextPassword2)

        // Initialize buttons and other components
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount)
        checkBox = findViewById(R.id.checkBox)

        // Initialize social media login options
        textViewFacebook = findViewById(R.id.textView7)
        textViewInstagram = findViewById(R.id.textView9)

        // Set up placeholder text clearing on focus
        setupPlaceholderBehavior()
    }

    private fun setupPlaceholderBehavior() {
        // Clear placeholder text when user starts typing
        editTextTextFullName.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus && editTextTextFullName.text.toString() == "       Full Name") {
                editTextTextFullName.setText("")
            }
        }

        editTextTextContactNumber.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus && editTextTextContactNumber.text.toString() == "       Contact Number") {
                editTextTextContactNumber.setText("")
            }
        }

        editTextTextEmailAddress.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus && editTextTextEmailAddress.text.toString() == "       Email Address") {
                editTextTextEmailAddress.setText("")
            }
        }

        editTextTextPassword.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus && editTextTextPassword.text.toString() == "       Password") {
                editTextTextPassword.setText("")
            }
        }

        editTextTextPassword2.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus && editTextTextPassword2.text.toString() == "       Confirm Password") {
                editTextTextPassword2.setText("")
            }
        }
    }

    private fun setupEventListeners() {
        // Create Account button click listener
        buttonCreateAccount.setOnClickListener {
            handleCreateAccount()
        }

        // Facebook login click listener
        textViewFacebook.setOnClickListener {
            handleFacebookLogin()
        }

        // Instagram login click listener
        textViewInstagram.setOnClickListener {
            handleInstagramLogin()
        }
    }

    private fun handleCreateAccount() {
        val fullName = editTextTextFullName.text.toString().trim()
        val contact = editTextTextContactNumber.text.toString().trim()
        val email = editTextTextEmailAddress.text.toString().trim()
        val password = editTextTextPassword.text.toString().trim()
        val confirmPassword = editTextTextPassword2.text.toString().trim()

        when {
            !checkBox.isChecked -> {
                Toast.makeText(
                    this,
                    "Please agree to Terms and Privacy Policy",
                    Toast.LENGTH_SHORT
                ).show()
            }

            fullName.isEmpty() || fullName == "Full Name" -> {
                Toast.makeText(this, "Please enter your full name", Toast.LENGTH_SHORT).show()
                editTextTextFullName.requestFocus()
            }

            contact.isEmpty() || contact == "Contact Number" -> {
                Toast.makeText(this, "Please enter your contact number", Toast.LENGTH_SHORT).show()
                editTextTextContactNumber.requestFocus()
            }

            email.isEmpty() || email == "Email Address" -> {
                Toast.makeText(this, "Please enter your email address", Toast.LENGTH_SHORT).show()
                editTextTextEmailAddress.requestFocus()
            }

            !isValidEmail(email) -> {
                Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show()
                editTextTextEmailAddress.requestFocus()
            }

            password.isEmpty() || password == "Password" -> {
                Toast.makeText(this, "Please enter a password", Toast.LENGTH_SHORT).show()
                editTextTextPassword.requestFocus()
            }

            confirmPassword.isEmpty() || confirmPassword == "Confirm Password" -> {
                Toast.makeText(this, "Please confirm your password", Toast.LENGTH_SHORT).show()
                editTextTextPassword2.requestFocus()
            }

            password != confirmPassword -> {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                editTextTextPassword2.requestFocus()
            }

            password.length < 6 -> {
                Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
                editTextTextPassword.requestFocus()
            }

            else -> {
                createAccount(fullName, contact, email, password)
            }
        }
    }

    private fun createAccount(fullName: String, contact: String, email: String, password: String) {
        with(sharedPreferences.edit()) {
            putString("user_${email}_password", password)
            putString("user_${email}_fullname", fullName)
            putString("user_${email}_contact", contact)
            apply()
        }

        Toast.makeText(this, "Account created successfully! Please login to continue.", Toast.LENGTH_LONG).show()

        val intent = Intent(this@MainActivity, LoginPage::class.java)
        intent.putExtra("REGISTERED_EMAIL", email) // Pass the email to pre-fill login
        startActivity(intent)
        finish()
    }

    private fun handleFacebookLogin() {
        Toast.makeText(this, "Facebook login clicked", Toast.LENGTH_SHORT).show()
    }

    private fun handleInstagramLogin() {
        Toast.makeText(this, "Instagram login clicked", Toast.LENGTH_SHORT).show()
    }

    private fun isValidEmail(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }
}