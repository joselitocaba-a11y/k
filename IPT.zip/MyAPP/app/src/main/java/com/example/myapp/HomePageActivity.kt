package com.example.myapp

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class HomePageActivity : AppCompatActivity() {

    private lateinit var navHome: ImageView
    private lateinit var navNotifications: ImageView
    private lateinit var navReturn: ImageView
    private lateinit var navSearch: ImageView
    private lateinit var navMenu: ImageView

    // Collection items
    private lateinit var stuffToyCollection: TextView
    private lateinit var shirtCollection: TextView
    private lateinit var figuresCollection: TextView
    private lateinit var storyCollection: TextView

    private lateinit var logoutText: TextView

    // Welcome message
    private lateinit var collectionsTitle: TextView

    private var userFullName: String? = null
    private var userEmail: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.homepage)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.HomePageActivity)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        userFullName = intent.getStringExtra("FULLNAME") ?: "Guest User"
        userEmail = intent.getStringExtra("EMAIL")

        initializeViews()
        setupEventListeners()
        setupWelcomeMessage()
    }

    private fun initializeViews() {
        navHome = findViewById(R.id.imageView3)
        navNotifications = findViewById(R.id.imageView4)
        navReturn = findViewById(R.id.imageView5)
        navSearch = findViewById(R.id.imageView7)
        navMenu = findViewById(R.id.imageView6)
        logoutText = findViewById(R.id.LogoutText)

        // Initialize collection items (from your XML)
        stuffToyCollection = findViewById(R.id.textView4)
        shirtCollection = findViewById(R.id.textView9)
        figuresCollection = findViewById(R.id.textView10)
        storyCollection = findViewById(R.id.textView11)

        // Initialize title
        collectionsTitle = findViewById(R.id.textView2)
    }

    private fun setupWelcomeMessage() {
        val welcomeText = "Welcome ${userFullName}!\nCollections"
        collectionsTitle.text = welcomeText

        Toast.makeText(this, "HI, ${userFullName} Welcome back!", Toast.LENGTH_LONG).show()
    }

    private fun setupEventListeners() {
        // Logout button (TextView)
        logoutText.setOnClickListener {
            Toast.makeText(this@HomePageActivity, "You've logged out", Toast.LENGTH_SHORT).show()

            val intent = Intent(this@HomePageActivity, LandingPage::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        navHome.setOnClickListener {
            Toast.makeText(this, "Going to Landing Page...", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@HomePageActivity, LandingPage::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        navNotifications.setOnClickListener {
            Toast.makeText(this, "You have no new notifications", Toast.LENGTH_SHORT).show()
        }

        navReturn.setOnClickListener {
            handleLogout()
        }

        navSearch.setOnClickListener {
            Toast.makeText(this, "Search: What are you looking for?", Toast.LENGTH_SHORT).show()
        }

        navMenu.setOnClickListener {
            showMenuOptions()
        }

        stuffToyCollection.setOnClickListener {
            Toast.makeText(this, "Opening Toothless Stuff Toy collection...", Toast.LENGTH_LONG).show()
            showCollectionDetails("Stuff Toy", "Browse our amazing collection of Toothless plush toys and collectibles!")
        }

        shirtCollection.setOnClickListener {
            Toast.makeText(this, "Opening Toothless Shirt collection...", Toast.LENGTH_LONG).show()
            showCollectionDetails("Shirts", "Check out our exclusive Toothless themed shirts and apparel!")
        }

        figuresCollection.setOnClickListener {
            Toast.makeText(this, "Opening Toothless Figures collection...", Toast.LENGTH_LONG).show()
            showCollectionDetails("Figures", "Discover our detailed Toothless action figures and models!")
        }

        storyCollection.setOnClickListener {
            Toast.makeText(this, "Opening Toothless Story collection...", Toast.LENGTH_LONG).show()
            showCollectionDetails("Story", "Read the epic tales and adventures of Toothless!")
        }
    }

    private fun showCollectionDetails(collectionName: String, description: String) {
        Toast.makeText(this, "$collectionName Collection:\n$description\n\n(Feature coming soon!)", Toast.LENGTH_LONG).show()
    }

    private fun handleLogout() {
        Toast.makeText(this, "Logging out... Goodbye ${userFullName}!", Toast.LENGTH_SHORT).show()

        val intent = Intent(this@HomePageActivity, LandingPage::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun showMenuOptions() {
        Toast.makeText(
            this,
            "🔧 Menu Options:\n" +
                    "• Profile Settings (Edit ${userFullName})\n" +
                    "• Order History\n" +
                    "• Favorites & Wishlist\n" +
                    "• Help & Support\n" +
                    "• About Dragon Store App\n" +
                    "• Logout",
            Toast.LENGTH_LONG
        ).show()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        Toast.makeText(this, "Press logout button to exit", Toast.LENGTH_SHORT).show()
    }
}