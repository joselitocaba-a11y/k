package com.example.myapp

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class LandingPage : AppCompatActivity() {

    private lateinit var exploreButton: TextView
    private lateinit var latestTrendsButton: TextView
    private lateinit var getStartedButton: TextView
    private lateinit var logoutText: TextView
    private lateinit var signInButton: TextView
    private lateinit var signUpButton: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.landing)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.LandingPage)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initializeViews()
        setupEventListeners()
    }

    private fun initializeViews() {
        exploreButton = findViewById(R.id.loginButton)
        latestTrendsButton = findViewById(R.id.registerBtn)
        getStartedButton = findViewById(R.id.textView2)
        logoutText = findViewById(R.id.LogoutText)

        // Add references to Sign In and Sign Up buttons
        signInButton = findViewById(R.id.loginButton)   // check your XML ID
        signUpButton = findViewById(R.id.registerBtn)   // check your XML ID
    }

    private fun setupEventListeners() {
        getStartedButton.setOnClickListener {
            val intent = Intent(this@LandingPage, MainActivity::class.java)
            startActivity(intent)
        }

        exploreButton.setOnClickListener {
            val intent = Intent(this@LandingPage, LoginPage::class.java)
            startActivity(intent)
        }

        latestTrendsButton.setOnClickListener {
            val intent = Intent(this@LandingPage, HomePageActivity::class.java)
            intent.putExtra("FULLNAME", "Guest User")
            startActivity(intent)
        }

        // Sign In → Login Page
        signInButton.setOnClickListener {
            Toast.makeText(this, "Opening Sign In...", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@LandingPage, LoginPage::class.java)
            startActivity(intent)
        }

        // Sign Up → Create Account Page
        signUpButton.setOnClickListener {
            Toast.makeText(this, "Opening Sign Up...", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@LandingPage, MainActivity::class.java)
            startActivity(intent)
        }
    }
}